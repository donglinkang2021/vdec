"""Standalone documentation runtime; no model backends."""
