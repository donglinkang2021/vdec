"""One authoritative drawing state for headless runs, human play and replay."""

from copy import deepcopy

COLORS = {"black": "#26354b", "red": "#d94854", "green": "#168765",
          "blue": "#3975d5", "orange": "#d58022", "purple": "#9354bd"}
TOOLS = {"geometry": ("line", "rectangle", "circle"), "freehand": ("pen",)}
ACTIONS = ("tool", "color", "move", "down", "up", "undo", "finish")
LIMITS = {"geometry": 64, "freehand": 256}


def validate_action(action, track):
    if not isinstance(action, dict) or action.get("action") not in ACTIONS:
        raise ValueError("Expected one action object with a known action")
    kind = action["action"]
    fields = {"tool": {"tool"}, "color": {"color"}, "move": {"x", "y"}}.get(kind, set())
    if set(action) != {"action"} | fields:
        raise ValueError("Action fields do not match its schema")
    if kind == "tool" and action["tool"] not in TOOLS[track]:
        raise ValueError("Tool is unavailable in this track")
    if kind == "color" and action["color"] not in COLORS:
        raise ValueError("Unknown color")
    if kind == "move" and any(type(action[k]) is not int or not 0 <= action[k] <= 80 for k in ("x", "y")):
        raise ValueError("Coordinates must be integers in [0, 80]; no clipping or rounding")
    return action


class Drawing:
    def __new__(cls, case=None, track="geometry", max_steps=None):
        if case is not None and case.get("dataset_version", "v1")=="v2":
            from .v2_environment import DrawingV2
            return DrawingV2(case,track,max_steps)
        return super().__new__(cls)

    def __init__(self, case, track="geometry", max_steps=None):
        if track not in TOOLS:
            raise ValueError("Unknown drawing track")
        self.case = deepcopy(case)
        self.track = track
        self.max_steps = LIMITS[track] if max_steps is None else max_steps
        if type(self.max_steps) is not int or self.max_steps < 1:
            raise ValueError("max_steps must be a positive integer")
        self.tool, self.color, self.cursor = TOOLS[track][0], "black", [40, 40]
        self.objects, self.active = [], None
        self.steps = self.invalid_actions = self.undo_count = 0
        self.terminal = None
        self.last_error = None

    def public_state(self):
        return dict(track=self.track, tool=self.tool, color=self.color, pen_down=self.active is not None,
                    steps_remaining=self.max_steps-self.steps, last_operation_error=self.last_error)

    def state(self):
        return deepcopy(dict(track=self.track, max_steps=self.max_steps, tool=self.tool, color=self.color,
            cursor=self.cursor, objects=self.objects, active=self.active, steps=self.steps,
            invalid_actions=self.invalid_actions, undo_count=self.undo_count,
            terminal=self.terminal, last_error=self.last_error))

    @classmethod
    def from_state(cls, case, state):
        if case is not None and case.get("dataset_version", "v1")=="v2":
            from .v2_environment import DrawingV2
            return DrawingV2.from_state(case,state)
        game = cls(case, state["track"], state["max_steps"])
        for key in game.state():
            setattr(game, key, deepcopy(state[key]))
        return game

    def step(self, action):
        if self.terminal:
            raise ValueError("Episode already ended")
        self.steps += 1
        self.last_error = None
        try:
            validate_action(action, self.track)
            op = action["action"]
            if op in ("tool", "color"):
                if self.active is not None:
                    raise ValueError("Lift or undo the active stroke before changing tool/color")
                setattr(self, op, action[op])
            elif op == "move":
                self.cursor = [action["x"], action["y"]]
                if self.active is not None:
                    if self.tool == "pen":
                        if self.active["points"][-1] != self.cursor:
                            self.active["points"].append(list(self.cursor))
                    else:
                        self.active["points"] = [self.active["points"][0], list(self.cursor)]
            elif op == "down":
                if self.active is not None:
                    raise ValueError("Pen is already down")
                self.active = dict(kind=self.tool, color=self.color, points=[list(self.cursor)])
            elif op == "up":
                if self.active is None:
                    raise ValueError("Pen is already up")
                self.objects.append(self.active)
                self.active = None
            elif op == "undo":
                if self.active is not None:
                    self.active = None
                elif self.objects:
                    self.objects.pop()
                else:
                    raise ValueError("No new stroke to undo; initial objects are immutable")
                self.undo_count += 1
            elif op == "finish":
                self.terminal = "submitted"  # An unfinished stroke is not silently lifted.
        except (ValueError, TypeError) as exc:
            self.invalid_actions += 1
            self.last_error = str(exc)
        if self.terminal is None and self.steps >= self.max_steps:
            self.terminal = "step_limit"
        return self.last_error
