"""Render the exact ink layers used by the v2 grader."""
from PIL import Image, ImageDraw
import numpy as np
from . import v2_ink as ink
from .rendering import ORIGIN,SIZE,SCALE


def render(game,selection=None):
    image=Image.new('RGB',SIZE,'#f0f3f8'); d=ImageDraw.Draw(image);ox,oy=ORIGIN
    d.text((24,17),'VDECISION / DRAWING V2',fill='#1e3049',font_size=22)
    d.text((24,45),f'{game.track} | {game.tool} | RGB {game.rgb} | {game.style} | {"DOWN" if game.active else "UP"}',fill='#53657c',font_size=13)
    scene=Image.new('RGB',(641,641),'white');s=ImageDraw.Draw(scene)
    for i in range(81):
        color='#e7edf5' if i%10==0 else '#f7f8fa'; s.line((i*8,0,i*8,640),fill=color);s.line((0,i*8,640,i*8),fill=color)
    for o in game.objects:
        scene.paste(tuple(o['rgb']),(0,0,641,641),Image.fromarray(ink.visible(o)))
    if game.active and game.tool!='eraser':
        a=game.active; mask=ink.get(ink.raster(a['kind'],a['points'],a['width'],a['style']))
        scene.paste(tuple(a['rgb']),(0,0,641,641),Image.fromarray(mask))
    s=ImageDraw.Draw(scene)
    for o in game.objects:
        ys,xs=np.nonzero(ink.visible(o))
        if not len(xs):continue
        x,y=int(xs.min()),int(ys.min());label=o['id']+(' [locked]' if not o['editable'] else '')
        s.text((x,max(0,y-16)),label,fill='#182c45',font_size=11)
        if o['id']==game.selected: s.rectangle((xs.min()-3,ys.min()-3,xs.max()+3,ys.max()+3),outline='#009a9a',width=2)
    image.paste(scene,ORIGIN);d=ImageDraw.Draw(image)
    for i in range(0,81,10):
        d.text((ox+i*8-5,oy+645),str(i),fill='#708198',font_size=11);d.text((ox-24,oy+i*8-5),str(i),fill='#708198',font_size=11)
    x,y=ox+game.cursor[0]*8,oy+game.cursor[1]*8
    d.ellipse((x-6,y-6,x+6,y+6),outline='#182c45',width=2);d.line((x-10,y,x+10,y),fill='#182c45');d.line((x,y-10,x,y+10),fill='#182c45')
    if selection is not None:
        lx,ly,width=selection;cell=width//3
        for row in range(3):
            for col in range(3):
                a,b=ox+(lx+col*cell-.5)*8,oy+(ly+row*cell-.5)*8
                d.rectangle((max(ox,a),max(oy,b),min(ox+640,a+cell*8),min(oy+640,b+cell*8)),outline='#198794',width=2)
        expanded=Image.new('RGB',(1088,SIZE[1]),'#f0f3f8');expanded.paste(image,(0,0))
        crop=scene.crop((max(0,(lx-.5)*8),max(0,(ly-.5)*8),min(641,(lx+width-.5)*8),min(641,(ly+width-.5)*8)))
        expanded.paste(crop.resize((324,324)),(748,160));d=ImageDraw.Draw(expanded)
        d.text((748,112),'SELECT NEXT TIP LOCATION',fill='#1e3049',font_size=17)
        for row in range(3):
            for col in range(3):
                a,b=748+108*col,160+108*row;d.rectangle((a,b,a+108,b+108),outline='#198794',width=2)
                d.rectangle((a+4,b+4,a+25,b+27),fill='white');d.text((a+7,b+5),str(row*3+col+1),fill='#166c77',font_size=18)
        image=expanded
    return image
