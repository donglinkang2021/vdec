"""Drawing v2 authoritative CPU environment with reversible ink edits."""
from copy import deepcopy
import numpy as np
from scipy import ndimage
from .v2_protocol import validate, color_rgb, TOOLS, LIMITS
from . import v2_ink as ink


class DrawingV2:
    def __init__(self,case,track='geometry',max_steps=None):
        if track not in TOOLS: raise ValueError('Unknown track')
        self.case=deepcopy(case); self.track=track
        self.max_steps=LIMITS[track] if max_steps is None else max_steps
        if type(self.max_steps) is not int or self.max_steps<1: raise ValueError('Invalid budget')
        self.tool=TOOLS[track][0]; self.color='black'; self.rgb=list(color_rgb({'color':'black'}))
        self.style='outline'; self.width=3; self.eraser_width=16; self.cursor=[40,40]
        self.objects=[self._object(o,initial=True) for o in case['initial']]
        self.active=None; self.selected=None; self.history=[]; self.next_id=1
        self.steps=self.invalid_actions=self.undo_count=0; self.terminal=self.last_error=None

    def _object(self,obj,initial=False):
        result=deepcopy(obj)
        result.update(rgb=list(color_rgb(obj)),style=obj.get('style','outline'),width=obj.get('width',3),
                      initial=initial,editable=obj.get('editable',False) if initial else True)
        result['ink']=ink.raster(result['kind'],result['points'],result['width'],result['style'])
        result['erased']=ink.EMPTY
        return result

    def public_state(self):
        return dict(dataset_version='v2',track=self.track,tool=self.tool,color=self.color,rgb=self.rgb,
                    style=self.style,width=self.eraser_width if self.tool=='eraser' else self.width,
                    pen_down=self.active is not None,selected_id=self.selected,
                    objects=[dict(id=o['id'],selected=o['id']==self.selected,editable=o['editable']) for o in self.objects],
                    steps_remaining=self.max_steps-self.steps,last_operation_error=self.last_error)

    def state(self):
        return deepcopy({k:v for k,v in vars(self).items() if k!='case'})

    @classmethod
    def from_state(cls,case,state):
        game=cls(case,state['track'],state['max_steps'])
        for k,v in state.items(): setattr(game,k,deepcopy(v))
        for key in ink.references(state): ink.get(key)
        return game

    def _snapshot(self): return deepcopy(dict(objects=self.objects,selected=self.selected,next_id=self.next_id))
    def _restore(self,snapshot):
        for k,v in snapshot.items(): setattr(self,k,deepcopy(v))

    def _selected(self):
        obj=next((o for o in self.objects if o['id']==self.selected),None)
        if obj is None or not obj['editable']: raise ValueError('Select an editable object first')
        return obj

    def _erase(self,a,b):
        if self.selected is not None: targets=[self._selected()]
        else: targets=[o for o in self.objects if o['editable']]
        for obj in targets: ink.erase(obj,a,b,self.eraser_width)

    def _edit(self,action):
        obj=self._selected(); op=action['operation']
        if op=='delete': self.objects.remove(obj); self.selected=None; return
        if op=='color':
            obj['rgb']=list(color_rgb(action)); obj.pop('color',None); return
        if op=='style':
            # Restyling acts on the intrinsic ink, then reapplies the same erasure.
            base=ink.get(obj['ink'])>0
            if action['style']=='solid': base=ndimage.binary_fill_holes(base)
            else: base=base & ~ndimage.binary_erosion(base,iterations=max(1,obj['width']))
            obj['ink']=ink.put(base.astype(np.uint8)*255); obj['style']=action['style']; return
        ys,xs=np.nonzero(ink.visible(obj))
        if not len(xs): raise ValueError('Cannot transform an empty object')
        cx,cy=(xs.min()+xs.max())/2,(ys.min()+ys.max())/2
        matrix=np.eye(3)
        if op=='move': matrix[:2,2]=[action['x']*8-cx,action['y']*8-cy]
        else:
            if op=='rotate':
                theta=np.deg2rad(action['angle']); c,s=np.cos(theta),np.sin(theta); matrix[:2,:2]=[[c,-s],[s,c]]
            else: matrix[:2,:2]*=action['percent']/100
            matrix[:2,2]=np.array([cx,cy])-matrix[:2,:2]@np.array([cx,cy])
        ink.transform(obj,matrix)

    def step(self,action):
        if self.terminal: raise ValueError('Episode already ended')
        self.steps+=1; self.last_error=None
        # A failed operation is atomic, including mutations of masks and history.
        before=self.state()
        try:
            validate(action,self.track); op=action['action']
            if self.active is not None and op in ('tool','color','style','width','select','edit'):
                raise ValueError('Lift or undo before changing settings or editing')
            if op in ('tool','style'): setattr(self,op,action[op])
            elif op=='width': setattr(self,'eraser_width' if self.tool=='eraser' else 'width',action['width'])
            elif op=='color': self.rgb=list(color_rgb(action)); self.color=action.get('color','custom')
            elif op=='select':
                if action['id'] is not None and not any(o['id']==action['id'] for o in self.objects): raise ValueError('Unknown object ID')
                self.selected=action['id']
            elif op=='edit':
                previous=self._snapshot(); self._edit(action); self.history.append(previous)
            elif op=='move':
                old=self.cursor; self.cursor=[action['x'],action['y']]
                if self.active is not None:
                    if self.tool=='eraser': self._erase(old,self.cursor)
                    elif self.tool in ('pen','polygon'):
                        if self.active['points'][-1]!=self.cursor: self.active['points'].append(list(self.cursor))
                    else: self.active['points']=[self.active['points'][0],list(self.cursor)]
            elif op=='down':
                if self.active is not None: raise ValueError('Already down')
                self.active=dict(kind=self.tool,rgb=list(self.rgb),style=self.style,width=self.width,
                                 points=[list(self.cursor)],before=self._snapshot())
                if self.tool=='eraser': self._erase(self.cursor,self.cursor)
            elif op=='up':
                if self.active is None: raise ValueError('Already up')
                if self.tool=='polygon' and not 3<=len(self.active['points'])<=8:
                    raise ValueError('Polygon requires 3 to 8 vertices')
                previous=self.active['before']
                if self.tool!='eraser':
                    obj={k:v for k,v in self.active.items() if k!='before'}
                    obj['id']=f'N{self.next_id}'; self.next_id+=1
                    self.objects.append(self._object(obj))
                self.history.append(previous); self.active=None
            elif op=='undo':
                if self.active is not None: self._restore(self.active['before']); self.active=None
                elif self.history: self._restore(self.history.pop())
                else: raise ValueError('No scene change to undo')
                self.undo_count+=1
            elif op=='finish': self.terminal='submitted'
        except (ValueError,TypeError,KeyError) as exc:
            for k,v in before.items(): setattr(self,k,v)
            self.invalid_actions+=1; self.last_error=str(exc)
        if self.terminal is None and self.steps>=self.max_steps: self.terminal='step_limit'
        return self.last_error
