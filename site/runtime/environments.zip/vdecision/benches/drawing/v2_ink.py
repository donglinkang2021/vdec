"""Content-addressed, lossless ink assets; object masks precede scene occlusion."""
import hashlib
from io import BytesIO
from pathlib import Path
from functools import lru_cache
import numpy as np
from PIL import Image, ImageDraw

SIZE=641
_ASSETS={}


def put(mask):
    array=np.asarray(mask,dtype=np.uint8)
    if array.shape!=(SIZE,SIZE): raise ValueError('Invalid ink dimensions')
    key=hashlib.sha256(array.tobytes()).hexdigest()
    if key not in _ASSETS:
        stream=BytesIO(); Image.fromarray(array).save(stream,format='PNG'); _ASSETS[key]=stream.getvalue()
    return key


@lru_cache(maxsize=64)
def get(key):
    if key not in _ASSETS: raise ValueError(f'Missing ink asset: {key}')
    with Image.open(BytesIO(_ASSETS[key])) as image: a=np.asarray(image.convert('L')).copy()
    if a.shape!=(SIZE,SIZE) or hashlib.sha256(a.tobytes()).hexdigest()!=key:
        raise ValueError('Corrupt ink asset')
    a.flags.writeable=False
    return a


def references(value):
    if isinstance(value,dict):
        for k,v in value.items():
            if k in ('ink','erased') and isinstance(v,str): yield v
            else: yield from references(v)
    elif isinstance(value,list):
        for v in value: yield from references(v)


def save(directory, state):
    directory=Path(directory)/'ink'; directory.mkdir(parents=True,exist_ok=True)
    for key in set(references(state)):
        get(key)
        path=directory/(key+'.png')
        if not path.exists(): path.write_bytes(_ASSETS[key])


def path_points(kind, points):
    p=np.asarray(points,dtype=float)
    if len(p)<2: return p
    a,b=p[0],p[-1]
    if kind in ('circle','ellipse'):
        if kind=='circle': center=a; rx=ry=np.linalg.norm(a-b)
        else: center=(a+b)/2; rx,ry=np.abs(a-b)/2
        angle=np.linspace(0,2*np.pi,129)
        return center + np.column_stack((rx*np.cos(angle),ry*np.sin(angle)))
    if kind=='rectangle':
        l,t=np.minimum(a,b); r,z=np.maximum(a,b)
        return np.array(((l,t),(r,t),(r,z),(l,z),(l,t)))
    if kind=='polygon' and len(p)>2: return np.vstack((p,p[0]))
    return p


def raster(kind,points,width=3,style='outline'):
    image=Image.new('L',(SIZE,SIZE)); d=ImageDraw.Draw(image)
    p=[tuple(v*8 for v in xy) for xy in path_points(kind,points)]
    if not p: return put(image)
    if style=='solid' and kind!='line' and len(p)>2: d.polygon(p,fill=255)
    if len(p)>1: d.line(p,fill=255,width=width,joint='curve')
    else:
        x,y=p[0]; d.ellipse((x-width/2,y-width/2,x+width/2,y+width/2),fill=255)
    return put(image)


EMPTY=put(np.zeros((SIZE,SIZE),np.uint8))


def visible(obj):
    return np.bitwise_and(get(obj['ink']),np.bitwise_not(get(obj['erased'])))


def erase(obj, a, b, diameter):
    image=Image.new('L',(SIZE,SIZE)); d=ImageDraw.Draw(image)
    points=[tuple(v*8 for v in p) for p in (a,b)]
    d.line(points,fill=255,width=diameter)
    for x,y in points:
        d.ellipse((x-diameter/2,y-diameter/2,x+diameter/2,y+diameter/2),fill=255)
    obj['erased']=put(np.maximum(get(obj['erased']),np.asarray(image)))


def transform(obj, matrix):
    """Transform actual ink and its erasure mask with the same affine map."""
    ink=get(obj['ink']); ys,xs=np.nonzero(visible(obj))
    if len(xs):
        mapped=np.column_stack((xs,ys,np.ones(len(xs)))) @ matrix.T
        if np.any(mapped[:,:2]<0) or np.any(mapped[:,:2]>640): raise ValueError('Transform would put ink outside the canvas')
    inverse=np.linalg.inv(matrix)
    for key in ('ink','erased'):
        image=Image.fromarray(get(obj[key]))
        obj[key]=put(image.transform((SIZE,SIZE),Image.Transform.AFFINE,tuple(inverse[:2].flat),resample=Image.Resampling.NEAREST))
    points=np.column_stack((np.asarray(obj['points'])*8,np.ones(len(obj['points']))))@matrix.T
    obj['points']=(points[:,:2]/8).tolist()

_DISK_VERIFIED={}

def load(directory, state):
    """Validate each immutable asset once per observed file revision, including replays."""
    for key in set(references(state)):
        path=Path(directory)/'ink'/(key+'.png');stat=path.stat();stamp=(stat.st_mtime_ns,stat.st_size)
        identity=(str(path.resolve()),key)
        if _DISK_VERIFIED.get(identity)==stamp and key in _ASSETS: continue
        _ASSETS[key]=path.read_bytes(); get.cache_clear(); get(key)
        _DISK_VERIFIED[identity]=stamp
