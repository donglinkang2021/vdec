"""Ink-derived fitting and constraint-pruned matching, without solution coordinates."""
from functools import lru_cache
from math import atan2, degrees
import numpy as np
from scipy import ndimage
from scipy.spatial import ConvexHull
from . import v2_ink as ink
from .v2_protocol import color_rgb


def simplify(points,tolerance=3):
    p=np.asarray(points,float)
    if len(p)<=2: return p
    a,b=p[0],p[-1]; v=b-a
    t=np.clip((p-a)@v/max(v@v,1e-9),0,1)
    distances=np.linalg.norm(p-(a+t[:,None]*v),axis=1); i=int(distances.argmax())
    if distances[i]<=tolerance: return p[[0,-1]]
    return np.vstack((simplify(p[:i+1],tolerance)[:-1],simplify(p[i:],tolerance)))


def boundary_polygon(mask):
    # Moore-neighborhood tracing preserves concavities, unlike a convex hull.
    filled=ndimage.binary_fill_holes(mask)
    y,x=np.argwhere(filled)[0]; start=(int(x),int(y)); current=start;back=(x-1,y)
    offsets=[(-1,0),(-1,-1),(0,-1),(1,-1),(1,0),(1,1),(0,1),(-1,1)]
    result=[]; first=None
    for _ in range(20000):
        delta=(back[0]-current[0],back[1]-current[1]); index=offsets.index(delta)
        found=None
        for n in range(8):
            k=(index+n)%8;dx,dy=offsets[k];xx,yy=current[0]+dx,current[1]+dy
            if 0<=xx<ink.SIZE and 0<=yy<ink.SIZE and filled[yy,xx]:
                found=(xx,yy);px,py=offsets[(k-1)%8];back=(current[0]+px,current[1]+py);break
        if found is None:return None
        if first is None:first=found
        elif current==start and found==first:break
        result.append(current);current=found
    else:return None
    if len(result)<3:return None
    points=simplify(np.array(result+[result[0]],float),4)
    return points if 3<=len(points)-1<=8 else None


def _fit(mask,kind):
    ys,xs=np.nonzero(mask)
    if len(xs)<12: return None
    p=np.column_stack((xs,ys)).astype(float)
    lo=p.min(axis=0); hi=p.max(axis=0); center=(lo+hi)/2
    w,h=hi-lo
    if kind=='line':
        _,vectors=np.linalg.eigh(np.cov(p.T)); direction=vectors[:,-1]
        along=(p-p.mean(axis=0))@direction
        points=np.array([p.mean(axis=0)+direction*v for v in (along.min(),along.max())])
        if np.linalg.norm(points[1]-points[0])<16: return None
    elif kind in ('circle','ellipse'):
        if min(w,h)<16: return None
        if kind=='circle':
            rx=ry=(w+h)/4
            if abs(w-h)>16: return None
            rotation=np.eye(2)
        else:
            # Covariance of the convex hull interior estimates ellipse orientation.
            hull=ConvexHull(p); interior=ink.get(ink.raster('polygon',(p[hull.vertices]/8).tolist(),1,'solid'))>0
            iy,ix=np.nonzero(interior); eig,vec=np.linalg.eigh(np.cov(np.column_stack((ix,iy)).T))
            rotation=vec[:,::-1]; q=(p-center)@rotation
            rx,ry=np.ptp(q,axis=0)/2
        theta=np.linspace(0,2*np.pi,129)
        points=center+np.column_stack((rx*np.cos(theta),ry*np.sin(theta)))@rotation.T
    elif kind in ('rectangle','polygon'):
        if min(w,h)<12: return None
        hull=ConvexHull(p); hp=p[hull.vertices]
        if kind=='rectangle':
            edges=np.roll(hp,-1,axis=0)-hp; angles=np.arctan2(edges[:,1],edges[:,0])
            best=None
            for a in angles:
                rot=np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]])
                q=p@rot; l=q.min(axis=0); r=q.max(axis=0); area=np.prod(r-l)
                if best is None or area<best[0]: best=(area,rot,l,r)
            _,rot,l,r=best
            points=np.array([[l[0],l[1]],[r[0],l[1]],[r[0],r[1]],[l[0],r[1]],[l[0],l[1]]])@rot.T
        else:
            points=boundary_polygon(mask)
            if points is None:return None
    else: return None
    return points


@lru_cache(maxsize=2048)
def fitted(ink_key,erase_key,kind,style,width,hint_key=None):
    actual=(ink.get(ink_key)>0)&~(ink.get(erase_key)>0)
    fit_mask=actual
    if width>8 and kind!='line':
        envelope=ndimage.binary_fill_holes(actual)
        core=ndimage.distance_transform_edt(envelope)>width/2
        if core.any():fit_mask=core & ~ndimage.binary_erosion(core)
    if hint_key is not None:fit_mask=ink.get(hint_key)>0
    try: points=_fit(fit_mask,kind)
    except (ValueError, RuntimeError): return None
    if points is None: return None
    expected_width=max(1,width)
    expected_key=ink.raster('line' if kind=='line' else 'polygon',(points/8).tolist(),expected_width,style)
    expected=ink.get(expected_key)>0
    if not expected.any(): return None
    # Bidirectional maximum distance checks every pixel; no averaging away holes.
    forward=float(ndimage.distance_transform_edt(~expected)[actual].max())
    reverse=float(ndimage.distance_transform_edt(~actual)[expected].max())
    error=max(forward,reverse)
    if kind!='line':
        interior=ndimage.binary_erosion(ink.get(ink.raster('polygon',(points/8).tolist(),1,'solid'))>0,iterations=max(2,width+(8 if style=="outline" else 2)))
        if interior.any():
            coverage=float(actual[interior].mean())
            if (style=='solid' and coverage<.9) or (style=='outline' and coverage>.1): error=max(error,9.)
    lo,hi=points.min(axis=0)/8,points.max(axis=0)/8
    length=np.linalg.norm(points[1]-points[0])/8 if kind=='line' else 0
    area=abs(np.dot(points[:,0],np.roll(points[:,1],1))-np.dot(points[:,1],np.roll(points[:,0],1)))/128
    center=(lo+hi)/2
    return dict(kind=kind,center=center.tolist(),box=[*lo,*hi],width=float(hi[0]-lo[0]),height=float(hi[1]-lo[1]),
                area=float(area),length=float(length),points=(points/8).tolist(),error=error,
                angle=degrees(atan2(*(points[1]-points[0])[::-1]))%180,
                mask=expected_key,valid=error<=8)


def fit_object(obj,kind,style):
    result=fitted(obj['ink'],obj['erased'],kind,style,obj['width'])
    if (result is None or not result['valid']) and obj['width']>8 and kind=='polygon':
        # A recorded path may propose a candidate, but cannot prove completion:
        # the same bidirectional distance and interior checks still use actual ink.
        hint=ink.raster(obj['kind'],obj['points'],1,'outline')
        alternative=fitted(obj['ink'],obj['erased'],kind,style,obj['width'],hint)
        if alternative is not None and (result is None or alternative['error']<result['error']):result=alternative
    return result


def relation(rule, objects):
    op=rule['op']; s=[objects[k] for k in rule['objects']]; a=s[0]; b=s[1] if len(s)>1 else None
    ca=np.array(a['center']); cb=np.array(b['center']) if b else None
    axis=rule.get('axis',0); tol=1.
    if op in ('left','right','above','below'):
        i=0 if op in ('left','right') else 1
        return (a['box'][i+2]+2<=b['box'][i]) if op in ('left','above') else (b['box'][i+2]+2<=a['box'][i])
    if op in ('align_x','align_y'):
        i=0 if op=='align_x' else 1
        return np.ptp([v['center'][i] for v in s])<=tol
    if op in ('between','fraction'):
        f=rule.get('fraction',.5); p=np.array(s[1]['center'])*(1-f)+np.array(s[2]['center'])*f
        return np.linalg.norm(ca-p)<=tol
    if op=='equal_spacing':
        differences=np.diff(np.array([v['center'] for v in s]),axis=0)
        return np.linalg.norm(differences,axis=1).min()>1 and np.max(np.linalg.norm(differences-differences[0],axis=1))<=tol
    if op=='translated_fraction':
        f=rule.get('fraction',.5); expected=(1-f)*np.array(s[1]['center'])+f*np.array(s[2]['center'])+np.array(s[3]['center'])-np.array(s[1]['center'])
        return np.linalg.norm(ca-expected)<=tol
    if op=='distance_ratio':
        d=np.linalg.norm(ca-cb); e=np.linalg.norm(np.array(s[2]['center'])-np.array(s[3]['center']))
        return abs(d-rule['ratio']*e)<=max(1,.1*rule['ratio']*e)
    if op in ('size_ratio','width_ratio','height_ratio','area_ratio','aspect'):
        keys=('width','height') if op=='size_ratio' else (op.split('_')[0],)
        if op=='aspect': return abs(a['width']/a['height']-rule['ratio'])<=.1*rule['ratio']
        return all(abs(a[k]-rule['ratio']*b[k])<=.1*rule['ratio']*b[k] for k in keys)
    if op in ('parallel','perpendicular','angle'):
        d=abs((a['angle']-b['angle']+90)%180-90)
        target={'parallel':0,'perpendicular':90}.get(op,rule.get('degrees',0))
        return abs(d-target)<=5
    if op=='mirror':
        expected=cb.copy(); expected[axis]=2*s[2]['center'][axis]-cb[axis]
        return np.linalg.norm(ca-expected)<=tol and all(abs(a[k]-b[k])<=max(.5,.1*b[k]) for k in ('width','height'))
    if op=='rotate_center':
        c=np.array(s[2]['center']); theta=np.deg2rad(rule['degrees']); rot=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])
        return np.linalg.norm(ca-(c+rot@(cb-c)))<=tol
    if op=='order': return all(y['center'][axis]-x['center'][axis]>1 for x,y in zip(s,s[1:]))
    if op=='connect':
        ends=np.array(a['points'])[[0,-1]]
        targets=np.array([s[1]['center'],s[2]['center']])
        return min(np.linalg.norm(ends-targets,axis=1).max(),np.linalg.norm(ends-targets[::-1],axis=1).max())<=1
    if op=='vertex_count': return len(a['points'])-1==rule['count']
    if op=='interior_angle':
        p=np.array(a['points'][:-1]); angles=[]
        for i,q in enumerate(p):
            u=p[i-1]-q; v=p[(i+1)%len(p)]-q
            angles.append(np.degrees(np.arccos(np.clip(u@v/np.linalg.norm(u)/np.linalg.norm(v),-1,1))))
        return any(abs(x-rule['degrees'])<=5 for x in angles)
    if op in ('inside','disjoint','overlap','contact'):
        ma=ink.get(ink.raster('polygon',a['points'],1,'solid'))>0
        mb=ink.get(ink.raster('polygon',b['points'],1,'solid'))>0
        if op=='inside': return bool(np.all(ndimage.distance_transform_edt(mb)[ma]>=16))
        if op=='disjoint': return bool(np.all(ndimage.distance_transform_edt(~mb)[ma]>=16))
        intersection=np.count_nonzero(ma&mb)
        if op=='overlap': return intersection>32 and intersection<.95*min(ma.sum(),mb.sum())
        return ndimage.distance_transform_edt(~mb)[ma].min()<=8 and intersection<=.1*min(ma.sum(),mb.sum())
    raise ValueError(f'Unknown v2 relation {op}')


def evaluate(game):
    goals=game.case['goals']; constraints=game.case['constraints']
    strokes=[o for o in game.objects if o['editable'] and np.any(ink.visible(o))]
    base=dict(success=False,object_count_correct=len(strokes)==len(goals),unfinished=game.active is not None,
              terminal=game.terminal,relations_correct=0,relations_total=len(constraints),shape_errors=[],
              color_errors=0,tool_errors=0,assignments=[],constraints=[],color_channel_error=[])
    initial={}
    for o in game.objects:
        if not o['editable']:
            f=fit_object(o,o['kind'],o['style'])
            if f is not None: initial[o['id']]=f
    if len(strokes)!=len(goals): return base
    candidates={}; diagnostics=[]
    for j,g in enumerate(goals):
        candidates[j]=[]
        for i,o in enumerate(strokes):
            f=fit_object(o,g['kind'],g.get('style','outline'))
            target=color_rgb(g) if g.get('color_mode')!='visual' else color_rgb(next(x for x in game.case['initial'] if x['id']==g['color_reference']))
            delta=[abs(x-y) for x,y in zip(o['rgb'],target)]
            close=not (o['kind']=='pen' and g['kind']!='line' and np.linalg.norm(np.array(o['points'][0])-o['points'][-1])>1)
            valid=f is not None and f['valid'] and close and o['style']==g.get('style','outline') and max(delta)<=(8 if g.get('color_mode')=='visual' else 0)
            if g.get('source_id') and o['id']!=g['source_id']: valid=False
            diagnostics.append((j,i,f,delta))
            if valid: candidates[j].append((i,f,delta))
    order=sorted(candidates,key=lambda j:len(candidates[j])); best=None; visited=0
    def search(depth,objects,used,assignment):
        nonlocal best,visited
        visited+=1
        checks=[dict(rule=r,passed=bool(relation(r,objects))) for r in constraints if all(k in objects for k in r['objects'])]
        if any(not c['passed'] for c in checks):
            if best is None or len(checks)>len(best[1]): best=(list(assignment),checks)
            return False
        if depth==len(order): best=(list(assignment),checks); return True
        j=order[depth]
        for i,f,delta in candidates[j]:
            if i in used: continue
            objects[goals[j]['id']]=f
            if search(depth+1,objects,used|{i},assignment+[(j,i,f,delta)]): return True
            del objects[goals[j]['id']]
        return False
    matched=search(0,dict(initial),set(),[])
    if best:
        assignments,checks=best
        base.update(relations_correct=sum(c['passed'] for c in checks),constraints=checks,
                    assignments=[dict(goal=goals[j]['id'],stroke=i) for j,i,f,d in assignments],
                    shape_errors=[f['error'] for j,i,f,d in assignments],color_channel_error=[d for j,i,f,d in assignments],
                    tool_errors=sum(not strokes[i]['initial'] and strokes[i]['kind']!=('pen' if game.track=='freehand' else goals[j]['kind']) for j,i,f,d in assignments))
    base['color_errors']=sum(not any(max(d)<= (8 if g.get('color_mode')=='visual' else 0) for jj,i,f,d in diagnostics if jj==j) for j,g in enumerate(goals))
    base['shape_errors'] = base['shape_errors'] or [min((f['error'] for jj,i,f,d in diagnostics if jj==j and f is not None),default=None) for j in range(len(goals))]
    base.update(success=bool(matched and not base['unfinished'] and game.terminal=='submitted'),matching_nodes=visited)
    return base
