"""Privileged rule trajectories; never used as a model input or model result."""
import numpy as np
from .v2_protocol import ACTIONS,TOOLS,COLORS,EDITS
from .v2_ink import path_points


def oracle_actions(case,track):
    actions=list(case.get('oracle_prefix',[]))
    for o in case['solution']:
        color={'rgb':o['rgb']} if 'rgb' in o else {'color':o['color']}
        actions += [dict(action='tool',tool='pen' if track=='freehand' else o['kind']),
                    dict(action='color',**color),dict(action='style',style=o.get('style','outline')),dict(action='width',width=o.get('width',3))]
        points=o['points']
        if track=='freehand':
            points=path_points(o['kind'],points)
            if o['kind'] in ('ellipse','circle'): points=points[::4]
            points=np.rint(points).astype(int).tolist()
        actions += [dict(action='move',x=points[0][0],y=points[0][1]),dict(action='down')]
        actions += [dict(action='move',x=p[0],y=p[1]) for p in points[1:]]
        actions.append(dict(action='up'))
    return actions+[dict(action='finish')]


def random_action(rng,track):
    op=rng.choice(ACTIONS); a=dict(action=op)
    if op=='edit': a['operation']=rng.choice(EDITS);op=a['operation']
    if op=='tool': a['tool']=rng.choice(TOOLS[track])
    elif op=='color':
        if rng.randrange(2): a['rgb']=[rng.randrange(256) for _ in range(3)]
        else:a['color']=rng.choice(list(COLORS))
    elif op=='style':a['style']=rng.choice(('outline','solid'))
    elif op=='width':a['width']=rng.randrange(1,33)
    elif op=='select':a['id']=rng.choice((None,'A','B','N1','N2'))
    elif op=='move':a.update(x=rng.randrange(81),y=rng.randrange(81))
    elif op=='rotate':a['angle']=rng.randrange(-180,181)
    elif op=='scale':a['percent']=rng.randrange(25,201)
    return a
