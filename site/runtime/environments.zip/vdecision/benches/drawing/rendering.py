"""Server-rendered observations, exactly shared by the model and local viewer."""

from io import BytesIO
from PIL import Image, ImageDraw
from .environment import COLORS
from .geometry import shape

RENDER_VERSION="drawing-render-v1"
ORIGIN=(48,76)
SCALE=8
SIZE=(736,752)


def render(game, selection=None):
    if game.case.get("dataset_version")=="v2":
        from .v2_rendering import render as render_v2
        return render_v2(game,selection)
    image=Image.new("RGB",SIZE,"#f0f3f8")
    d=ImageDraw.Draw(image)
    d.text((24,17),"VDECISION / DRAWING",fill="#1e3049",font_size=22)
    d.text((24,45),f"{game.track}  |  {game.tool} / {game.color}  |  {'DOWN' if game.active else 'UP'}",fill="#53657c",font_size=15)
    ox,oy=ORIGIN
    d.rectangle((ox,oy,ox+640,oy+640),fill="white",outline="#9cadc3")
    for i in range(81):
        x,y=ox+i*SCALE,oy+i*SCALE
        grid_color="#e7edf5" if i%10==0 else "#f7f8fa"
        d.line((x,oy,x,oy+640),fill=grid_color)
        d.line((ox,y,ox+640,y),fill=grid_color)
        if i%10: continue
        d.text((x-5,oy+645),str(i),fill="#708198",font_size=11)
        d.text((ox-24,y-5),str(i),fill="#708198",font_size=11)
    background=image.copy()
    def pos(p): return (ox+p[0]*SCALE,oy+p[1]*SCALE)
    def draw_obj(obj, label=None):
        points=obj["points"]
        color=COLORS[obj["color"]]
        if obj["kind"]=="pen":
            if len(points)>1: d.line([pos(p) for p in points],fill=color,width=3,joint="curve")
            else:
                x,y=pos(points[0]); d.ellipse((x-1,y-1,x+1,y+1),fill=color)
            box=None
        else:
            s=shape(obj["kind"],points)
            if s is None:
                x,y=pos(points[0]); d.ellipse((x-2,y-2,x+2,y+2),fill=color); return
            box=(*pos(s["box"][:2]),*pos(s["box"][2:]))
            if obj["kind"]=="line": d.line([pos(p) for p in points],fill=color,width=3)
            elif obj["kind"]=="circle": d.ellipse(box,outline=color,width=3)
            else: d.rectangle(box,outline=color,width=3)
        if label and box:
            d.text((box[0],max(oy,box[1]-19)),label,fill=color,font_size=16)
    # Draw only scene content inside the canvas; larger shapes remain in state for invalid-bound grading.
    for o in game.case["initial"]: draw_obj(o,o["id"])
    for o in game.objects: draw_obj(o)
    if game.active: draw_obj(game.active)
    scene=image.crop((ox,oy,ox+641,oy+641))
    image=background
    image.paste(scene,(ox,oy))
    d=ImageDraw.Draw(image)
    if selection is not None:
        lx,ly,width=selection
        cell=width//3
        for row in range(3):
            for col in range(3):
                x0=ox+(lx+col*cell-.5)*SCALE
                y0=oy+(ly+row*cell-.5)*SCALE
                x1,y1=x0+cell*SCALE,y0+cell*SCALE
                d.rectangle((max(ox,x0),max(oy,y0),min(ox+640,x1),min(oy+640,y1)),outline="#31949e",width=2)
                # Keep small-cell labels legible without changing the underlying scene.
                d.text((x0+2,y0+2),str(row*3+col+1),fill="#166c77",font_size=12)
    x,y=pos(game.cursor)
    d.ellipse((x-6,y-6,x+6,y+6),outline="#182c45",width=2)
    d.line((x-10,y,x+10,y),fill="#182c45",width=1)
    d.line((x,y-10,x,y+10),fill="#182c45",width=1)
    if selection is not None:
        # Keep late localization choices readable: the full scene remains visible,
        # and a separate magnifier shows only the selected region, never a target.
        lx,ly,width=selection
        expanded=Image.new("RGB",(1088,SIZE[1]),"#f0f3f8")
        expanded.paste(image,(0,0))
        crop=scene.crop((max(0,(lx-.5)*8),max(0,(ly-.5)*8),min(641,(lx+width-.5)*8),min(641,(ly+width-.5)*8)))
        expanded.paste(crop.resize((324,324)),(748,160))
        z=ImageDraw.Draw(expanded)
        z.text((748,112),"SELECT NEXT TIP LOCATION",fill="#1e3049",font_size=17)
        for row in range(3):
            for col in range(3):
                x0,y0=748+108*col,160+108*row
                z.rectangle((x0,y0,x0+108,y0+108),outline="#198794",width=2)
                z.rectangle((x0+4,y0+4,x0+25,y0+27),fill="white")
                z.text((x0+7,y0+5),str(row*3+col+1),fill="#166c77",font_size=18)
        image=expanded
    return image


def png_bytes(game, selection=None):
    stream=BytesIO()
    render(game,selection).save(stream,format="PNG")
    return stream.getvalue()
