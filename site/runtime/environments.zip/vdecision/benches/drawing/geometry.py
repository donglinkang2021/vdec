"""Continuous contour geometry in logical grid units (one unit = 8 pixels)."""

from math import ceil, cos, dist, hypot, pi, sin, sqrt

TOLERANCE = 1.0
SEPARATION = 2.0


def segment_distance(p, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    length2 = dx*dx + dy*dy
    t = max(0., min(1., ((p[0]-a[0])*dx+(p[1]-a[1])*dy)/length2)) if length2 else 0.
    return hypot(p[0]-a[0]-t*dx, p[1]-a[1]-t*dy)


def resample(points, spacing=.25):
    if not points:
        return []
    sampled = [tuple(points[0])]
    for a, b in zip(points, points[1:]):
        n = max(1, ceil(dist(a, b)/spacing))
        sampled.extend((a[0]+(b[0]-a[0])*i/n, a[1]+(b[1]-a[1])*i/n) for i in range(1, n+1))
    return sampled


def shape(kind, points):
    if len(points) < 2:
        return None
    a, b = points[0], points[-1]
    if kind == "circle":
        radius = dist(a, b)
        if radius < 2:
            return None
        box = [a[0]-radius, a[1]-radius, a[0]+radius, a[1]+radius]
        result = dict(kind=kind, center=list(a), radius=radius, box=box)
    else:
        box = [min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1])]
        if kind == "line" and dist(a, b) < 2:
            return None
        if kind == "rectangle" and min(box[2]-box[0], box[3]-box[1]) < 2:
            return None
        result = dict(kind=kind, center=[(box[0]+box[2])/2, (box[1]+box[3])/2], box=box,
                      points=[list(a), list(b)])
    result.update(width=box[2]-box[0], height=box[3]-box[1])
    return result


def contour(s, spacing=.25):
    if s["kind"] == "line":
        return resample(s["points"], spacing)
    if s["kind"] == "rectangle":
        l, t, r, b = s["box"]
        return resample([(l,t), (r,t), (r,b), (l,b), (l,t)], spacing)
    n = max(32, ceil(2*pi*s["radius"]/spacing))
    cx, cy = s["center"]
    return [(cx+s["radius"]*cos(2*pi*i/n), cy+s["radius"]*sin(2*pi*i/n)) for i in range(n)]


def contour_distance(p, s):
    if s["kind"] == "circle":
        return abs(dist(p, s["center"])-s["radius"])
    if s["kind"] == "line":
        return segment_distance(p, *s["points"])
    l, t, r, b = s["box"]
    return min(segment_distance(p, a, z) for a,z in
               [((l,t),(r,t)), ((r,t),(r,b)), ((r,b),(l,b)), ((l,b),(l,t))])


def infer(stroke, expected_kind):
    """Fit only to the actual ink; never use reference/target coordinates."""
    points = stroke["points"]
    if stroke["kind"] != "pen":
        s = shape(stroke["kind"], points)
        return (s, 0.) if s is not None and stroke["kind"] == expected_kind else (None, None)
    samples = resample(points)
    if len(samples) < 3:
        return None, None
    if expected_kind == "line":
        s = shape("line", [points[0], points[-1]])
    else:
        if dist(points[0], points[-1]) > TOLERANCE:
            return None, None
        xs, ys = [p[0] for p in samples], [p[1] for p in samples]
        if expected_kind == "rectangle":
            s = shape("rectangle", [(min(xs), min(ys)), (max(xs), max(ys))])
        else:
            # Algebraic circle fit, translated to improve numerical conditioning.
            mx, my = sum(xs)/len(xs), sum(ys)/len(ys)
            uv = [(x-mx, y-my) for x,y in samples]
            uu, vv = sum(u*u for u,v in uv), sum(v*v for u,v in uv)
            cross = sum(u*v for u,v in uv)
            det = uu*vv-cross*cross
            if abs(det) < 1e-9:
                return None, None
            ru = .5*sum(u*(u*u+v*v) for u,v in uv)
            rv = .5*sum(v*(u*u+v*v) for u,v in uv)
            center = (mx+(ru*vv-rv*cross)/det, my+(rv*uu-ru*cross)/det)
            radius = sqrt(sum(dist(p, center)**2 for p in samples)/len(samples))
            s = shape("circle", [center, (center[0]+radius, center[1])])
    if s is None:
        return None, None
    segments = list(zip(points, points[1:]))
    forward = max(contour_distance(p, s) for p in samples)
    # Reverse direction rejects partial outlines and corner-only shortcuts.
    reverse = max(min(segment_distance(p, a,b) for a,b in segments) for p in contour(s))
    error = max(forward, reverse)
    return (s if error <= TOLERANCE else None), error


def contained(a, b, margin=SEPARATION):
    return (a["box"][0] >= b["box"][0]+margin and a["box"][1] >= b["box"][1]+margin
            and a["box"][2] <= b["box"][2]-margin and a["box"][3] <= b["box"][3]-margin)


def separated(a, b, gap=SEPARATION):
    # Filled extents, not just outlines: nested shapes are not disjoint objects.
    if a["kind"] == b["kind"] == "circle":
        return dist(a["center"], b["center"]) >= a["radius"]+b["radius"]+gap
    if a["kind"] == "circle" or b["kind"] == "circle":
        circle, other = (a,b) if a["kind"] == "circle" else (b,a)
        if other["kind"] == "line":
            d = segment_distance(circle["center"], *other["points"])
        else:
            x,y = circle["center"]
            l,t,r,bottom = other["box"]
            d = hypot(max(l-x, 0., x-r), max(t-y, 0., y-bottom))
        return d >= circle["radius"]+gap
    # V1 uses axis-aligned rectangles and horizontal/vertical lines in separation tasks.
    l,t,r,bottom = a["box"]
    ll,tt,rr,bb = b["box"]
    return hypot(max(l-rr,ll-r,0.), max(t-bb,tt-bottom,0.)) >= gap


def relation(rule, objects):
    op, names = rule["op"], rule["objects"]
    shapes = [objects[n] for n in names]
    a, b = shapes[:2]
    if op in ("left", "right", "above", "below"):
        if op == "left": return a["box"][2] <= b["box"][0]-SEPARATION
        if op == "right": return a["box"][0] >= b["box"][2]+SEPARATION
        if op == "above": return a["box"][3] <= b["box"][1]-SEPARATION
        return a["box"][1] >= b["box"][3]+SEPARATION
    if op in ("align_x", "align_y"):
        axis = 0 if op == "align_x" else 1
        values = [s["center"][axis] for s in shapes]
        return max(values)-min(values) <= TOLERANCE
    if op == "between":
        c = shapes[2]
        return dist(a["center"], [(b["center"][i]+c["center"][i])/2 for i in (0,1)]) <= TOLERANCE
    if op == "equal_spacing":
        axis = rule["axis"]
        gaps = [y["center"][axis]-x["center"][axis] for x,y in zip(shapes, shapes[1:])]
        return min(gaps) > 0 and max(gaps)-min(gaps) <= TOLERANCE
    if op == "inside":
        return contained(a, b)
    if op == "disjoint":
        return separated(a, b)
    if op == "size_ratio":
        return all(b[key] > 0 and abs(a[key]/b[key]-rule["ratio"]) <= .1*rule["ratio"]
                   for key in ("width", "height"))
    raise ValueError(f"Unknown relation {op}")
