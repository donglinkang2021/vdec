"""Versioned canonical action schemas. Validation never changes an action."""
from .environment import COLORS as LEGACY_COLORS, ACTIONS as LEGACY_ACTIONS

VERSION = 'drawing-bench-v2'
COLORS = dict(LEGACY_COLORS, white='#ffffff', yellow='#f1cc28', cyan='#00b8d4',
              magenta='#d62aa0', gray='#808080', brown='#80502e', pink='#ed90b5',
              navy='#162d63', teal='#008080', lime='#70c62c')
TOOLS = {'geometry': ('line','rectangle','circle','ellipse','polygon','eraser'),
         'freehand': ('pen','eraser')}
ACTIONS = LEGACY_ACTIONS + ('style','width','select','edit')
EDITS = ('move','rotate','scale','color','style','delete')
LIMITS = {'geometry':192, 'freehand':768}


def integer(value, lo, hi):
    return type(value) is int and lo <= value <= hi


def rgb_value(value):
    if not isinstance(value, (list, tuple)) or len(value)!=3 or not all(integer(v,0,255) for v in value):
        raise ValueError('RGB must contain three integers in [0,255] (no booleans)')
    return tuple(value)


def color_rgb(obj):
    if 'rgb' in obj: return rgb_value(obj['rgb'])
    value = COLORS[obj['color']].lstrip('#')
    return tuple(int(value[i:i+2],16) for i in (0,2,4))


def validate(action, track):
    if not isinstance(action,dict) or action.get('action') not in ACTIONS:
        raise ValueError('Expected one canonical action object')
    op=action['action']; fields=set()
    if op=='edit':
        if action.get('operation') not in EDITS: raise ValueError('Unknown edit operation')
        fields.add('operation'); op=action['operation']
    if op=='color':
        if ('rgb' in action)==('color' in action): raise ValueError('Supply exactly one of color and rgb')
        if 'rgb' in action: rgb_value(action['rgb']); fields.add('rgb')
        else:
            if not isinstance(action['color'],str) or action['color'] not in COLORS: raise ValueError('Unknown preset')
            fields.add('color')
    elif op=='tool':
        fields.add('tool')
        if action.get('tool') not in TOOLS[track]: raise ValueError('Unavailable tool')
    elif op=='style':
        fields.add('style')
        if action.get('style') not in ('outline','solid'): raise ValueError('Unknown style')
    elif op=='select':
        fields.add('id')
        if action.get('id') is not None and not isinstance(action.get('id'),str): raise ValueError('ID must be a string or null')
    elif op=='move':
        fields.update(('x','y'))
        if not all(integer(action.get(k),0,80) for k in ('x','y')): raise ValueError('Coordinates must be integers in [0,80]')
    elif op in ('width','rotate','scale'):
        key,lo,hi={'width':('width',1,32),'rotate':('angle',-180,180),'scale':('percent',25,200)}[op]
        fields.add(key)
        if not integer(action.get(key),lo,hi): raise ValueError(f'{key} must be an integer in [{lo},{hi}]')
    if set(action) != {'action'}|fields: raise ValueError('Unexpected or missing action fields')
    return action
