"""Deterministic screenshot-only Snake; no action masks or model-visible state."""

import random
from copy import deepcopy
from dataclasses import dataclass, field
from PIL import Image, ImageDraw

DIRECTIONS = ((0, -1), (1, 0), (0, 1), (-1, 0))
CLASSIC_RULES = (
    "Play Snake on a 10 by 10 board. The blue head has a white arrow showing its direction; "
    "green cells are the body and the red circle is food. Each action moves one cell. "
    "Left and right turn relative to the current heading; straight keeps the heading. "
    "Eating food grows the snake. Hitting a wall or the body ends the game; "
    "the tail vacates its cell on a non-eating move. Maximize food and survival. "
    "Use the CURRENT screenshot to adapt any earlier plan."
)
RENDER_VERSIONS = ("topology_v2", "classic_v1")
RULES = CLASSIC_RULES.replace(
    "green cells are the body and the red circle is food.",
    "connected green segments form the body, fading lighter from neck to the pointed tail; "
    "only consecutive body segments are connected. The red circle is food.")


def rules_for(render_version="topology_v2"):
    if render_version not in RENDER_VERSIONS:
        raise ValueError(f"Unknown render version: {render_version}")
    return CLASSIC_RULES if render_version == "classic_v1" else RULES
CHOICES = [("left", "Turn left"), ("straight", "Go straight"), ("right", "Turn right")]
QUESTION = "Which action should the snake take next?"


def reference_image(render_version="topology_v2"):
    """Independent appearance example, never the live game's observation."""
    return Snake(0, food=(2, 2)).render(render_version)


@dataclass
class Snake:
    seed: int
    size: int = 10
    body: list[tuple[int, int]] = field(default_factory=lambda: [(5, 5), (4, 5), (3, 5)])
    direction: int = 1
    food: tuple[int, int] | None = None
    steps: int = 0
    foods: int = 0
    terminal: str | None = None
    max_steps: int = 128

    def __post_init__(self):
        if type(self.max_steps) is not int or self.max_steps < 1:
            raise ValueError("max_steps must be a positive integer")
        self.rng = random.Random(self.seed)
        if self.food is None:
            self.spawn_food()

    def spawn_food(self):
        free = [(x, y) for y in range(self.size) for x in range(self.size) if (x, y) not in self.body]
        self.food = self.rng.choice(free) if free else None
        if not free:
            self.terminal = "board_full"

    def step(self, action: str) -> dict:
        if self.terminal:
            raise ValueError("Episode already ended")
        self.direction = (self.direction + {"left": -1, "straight": 0, "right": 1}[action]) % 4
        dx, dy = DIRECTIONS[self.direction]
        head = (self.body[0][0] + dx, self.body[0][1] + dy)
        eating = head == self.food
        self.steps += 1
        if not all(0 <= x < self.size for x in head):
            self.terminal = "wall"
        elif head in (self.body if eating else self.body[:-1]):
            self.terminal = "body"
        else:
            self.body.insert(0, head)
            if eating:
                self.foods += 1
                self.spawn_food()
            else:
                self.body.pop()
        if self.steps >= self.max_steps and self.terminal is None:
            self.terminal = "step_limit"
        return self.state()

    def state(self) -> dict:
        # Evaluation output only; never added to a prompt.
        return {"size": self.size, "body": self.body.copy(), "direction": self.direction, "food": self.food,
                "steps": self.steps, "foods": self.foods, "terminal": self.terminal, "max_steps": self.max_steps}

    def render(self, render_version="topology_v2") -> Image.Image:
        rules_for(render_version)
        if render_version == "topology_v2":
            from .rendering import render_board
            return render_board(self)
        return self._render_classic()

    def _render_classic(self) -> Image.Image:
        image = Image.new("RGB", (320, 320), "#f7f7f7")
        draw = ImageDraw.Draw(image)
        cell = 320 // self.size
        for i in range(self.size + 1):
            draw.line((i * cell, 0, i * cell, 320), fill="#333333")
            draw.line((0, i * cell, 320, i * cell), fill="#333333")
        for j, (x, y) in enumerate(self.body):
            draw.rectangle((x * cell + 3, y * cell + 3, (x + 1) * cell - 3, (y + 1) * cell - 3),
                           fill="#1368ce" if j == 0 else "#36a85a")
        if self.food:
            x, y = self.food
            draw.ellipse((x * cell + 7, y * cell + 7, (x + 1) * cell - 7, (y + 1) * cell - 7), fill="#ee2525")
        x, y = self.body[0]
        cx, cy = (x + .5) * cell, (y + .5) * cell
        dx, dy = DIRECTIONS[self.direction]
        draw.line((cx - dx * 8, cy - dy * 8, cx + dx * 9, cy + dy * 9), fill="white", width=4)
        draw.polygon([(cx + dx * 11, cy + dy * 11),
                      (cx + dx * 2 - dy * 7, cy + dy * 2 + dx * 7),
                      (cx + dx * 2 + dy * 7, cy + dy * 2 - dx * 7)], fill="white")
        return image


def validate_state(game):
    cells = game.body
    if (len(cells) < 2 or len(set(cells)) != len(cells) or game.food in cells
            or game.direction not in range(4) or game.food is None
            or any(not (0 <= x < game.size and 0 <= y < game.size) for x, y in [*cells, game.food])
            or any(abs(a[0]-b[0]) + abs(a[1]-b[1]) != 1 for a, b in zip(cells, cells[1:]))
            or (cells[0][0]-cells[1][0], cells[0][1]-cells[1][1]) != DIRECTIONS[game.direction]):
        raise ValueError("Invalid diagnostic Snake state")


def rotate_game(game, turns):
    result = deepcopy(game)
    def point(p):
        x, y = p
        for _ in range(turns):
            x, y = game.size - 1 - y, x
        return x, y
    result.body = [point(p) for p in game.body]
    result.food = point(game.food)
    result.direction = (game.direction + turns) % 4
    validate_state(result)
    return result


def action_facts(game):
    """Evaluation only: no caller may put these answers into model prompts."""
    facts = {}
    distance = lambda p: abs(p[0]-game.food[0]) + abs(p[1]-game.food[1])
    for action, _ in CHOICES:
        trial = deepcopy(game)
        trial.step(action)
        collision = trial.terminal in ("wall", "body")
        facts[action] = {"collision": collision, "heading": trial.direction,
                         "approaches_food": not collision and distance(trial.body[0]) < distance(game.body[0])}
    return facts
