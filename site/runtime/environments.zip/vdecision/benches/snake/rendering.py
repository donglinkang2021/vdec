"""Deterministic board and presentation card rendering; no model dependencies."""
from functools import lru_cache
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from .environment import CHOICES, DIRECTIONS, QUESTION, Snake

BG = "#090f1b"
PANEL = "#101c2d"
TEXT = "#edf5ff"
MUTED = "#91a5bf"
GREEN = "#6ee7b7"
BLUE = "#3987ff"
CARD_SIZE = (400, 640)


def game_from_state(state):
    # __post_init__ normally spawns food when None: restore it for board-full frames.
    game = Snake(0, size=state.get("size", 10), body=[tuple(p) for p in state["body"]],
                 direction=state["direction"], food=tuple(state["food"]) if state.get("food") else None,
                 steps=state.get("steps", 0), foods=state.get("foods", 0), terminal=state.get("terminal"),
                 max_steps=state.get("max_steps", 128))
    game.food = tuple(state["food"]) if state.get("food") else None
    return game


def render_board(game):
    scale = 3
    side = 320 * scale
    cell = side / game.size
    image = Image.new("RGB", (side, side), BG)
    draw = ImageDraw.Draw(image)
    for y in range(game.size):
        for x in range(game.size):
            draw.rectangle((x*cell, y*cell, (x+1)*cell, (y+1)*cell),
                           fill="#111e30" if (x+y) % 2 else "#132238")
    for i in range(game.size + 1):
        draw.line((i*cell, 0, i*cell, side), fill="#20314a", width=scale)
        draw.line((0, i*cell, side, i*cell), fill="#20314a", width=scale)
    centers = [((x+.5)*cell, (y+.5)*cell) for x, y in game.body]
    colors = []
    for i in range(len(centers)):
        t = 1. if i == len(centers)-1 else (i-1) / max(1, len(centers)-2)
        colors.append(tuple(round(a+(b-a)*max(0, t)) for a,b in zip((30,165,126),(167,243,208))))
    radius = cell * .31
    # Only ordered neighbors get a bridge. Nearby non-neighbors retain a gap.
    for i in range(1, len(centers)):
        a, b = centers[i-1], centers[i]
        if i == len(centers)-1:
            b = (b[0] + (a[0]-b[0])/cell*radius, b[1] + (a[1]-b[1])/cell*radius)
        draw.line((*a, *b), fill=colors[i], width=round(radius*1.65))
    for i, (cx, cy) in enumerate(centers):
        if i == len(centers)-1 and i:
            px, py = centers[i-1]
            dx, dy = (cx-px)/cell, (cy-py)/cell
            draw.polygon([(cx+dx*radius, cy+dy*radius),
                          (cx-dx*radius-dy*radius*.825, cy-dy*radius+dx*radius*.825),
                          (cx-dx*radius+dy*radius*.825, cy-dy*radius-dx*radius*.825)], fill=colors[i])
        else:
            draw.rounded_rectangle((cx-radius, cy-radius, cx+radius, cy+radius),
                                   radius=cell*.17, fill=BLUE if i == 0 else colors[i])
    cx, cy = centers[0]
    dx, dy = DIRECTIONS[game.direction]
    draw.line((cx-dx*cell*.16, cy-dy*cell*.16, cx+dx*cell*.16, cy+dy*cell*.16),
              fill="white", width=3*scale)
    draw.polygon([(cx+dx*cell*.24, cy+dy*cell*.24),
                  (cx-dy*cell*.14, cy+dx*cell*.14), (cx+dy*cell*.14, cy-dx*cell*.14)], fill="white")
    if game.food is not None:
        x,y = game.food
        cx,cy = (x+.5)*cell,(y+.5)*cell
        r = cell*.24
        draw.ellipse((cx-r-3,cy-r-3,cx+r+3,cy+r+3), fill="#613142")
        draw.ellipse((cx-r,cy-r,cx+r,cy+r), fill="#ff647c")
        draw.ellipse((cx-r*.55,cy-r*.55,cx-r*.1,cy-r*.1), fill="#ffc2cc")
    return image.resize((320, 320), Image.Resampling.LANCZOS)


@lru_cache(maxsize=16)
def font(size):
    for path in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                 "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"):
        if Path(path).is_file():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default(size=size)


def wrap(draw, text, width, face):
    lines, current = [], ""
    for char in str(text):
        if char == "\n" or draw.textlength(current + char, font=face) > width:
            lines.append(current.rstrip())
            current = "" if char == "\n" else char
        else:
            current += char
    return lines + [current.rstrip()]


def render_card(frame):
    """A frame always couples a pre-action board with that decision's scores."""
    image = Image.new("RGB", CARD_SIZE, BG)
    draw = ImageDraw.Draw(image)
    question_lines = wrap(draw, frame.get("question", QUESTION), 352, font(14))
    # Long questions expand the card instead of silently truncating the prompt.
    extra = max(0, len(question_lines)-2) * 19
    if extra:
        image = Image.new("RGB", (400, 640+extra), BG)
        draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((1,1,398,image.height-2), radius=20, outline="#2a3c56", width=2)
    draw.text((24,16), "SNAKE / DECISION LAB", font=font(16), fill=TEXT)
    title = str(frame.get("model", "vdecision"))
    while draw.textlength(title, font=font(11)) > 350:
        title = title[1:]
    draw.text((24,40), title, font=font(11), fill=MUTED)
    game = game_from_state(frame["state"])
    image.paste(game.render(frame.get("render_version", "topology_v2")), (40,64))
    draw.text((24,397), f"STEP {game.steps:03d}     FOOD {game.foods:02d}", font=font(12), fill=GREEN)
    status = str(frame.get("status", "ready"))
    draw.text((230,397), status[:22], font=font(11), fill=MUTED)
    for i,line in enumerate(question_lines):
        draw.text((24,423+i*19), line, font=font(14), fill=TEXT)
    y = 469 + extra
    draw.text((24,y), "NORMALIZED ACTION SCORES", font=font(10), fill=MUTED)
    scores = {r["id"]: r for r in frame.get("candidates", [])}
    choices = dict(frame.get("choices", CHOICES))
    for i,(key, fallback) in enumerate(CHOICES):
        top = y+20+i*31
        selected = frame.get("action") == key
        draw.text((24,top+2), choices.get(key, fallback), font=font(12), fill=GREEN if selected else TEXT)
        draw.rounded_rectangle((130,top+3,306,top+17), radius=7, fill="#24354c")
        row = scores.get(key)
        if row:
            score = float(row["score"])
            width = round(176 * max(0, min(1, score)))
            if width > 0:
                draw.rounded_rectangle((130,top+3,130+max(2,width),top+17), radius=min(7,width//2),
                                       fill=GREEN if selected else BLUE)
            draw.text((315,top+1), f"{score:.1%}", font=font(12), fill=GREEN if selected else TEXT)
        else:
            draw.text((315,top+1), "--", font=font(12), fill=MUTED)
    method = frame.get("method", "")
    note = "No model scores" if method in ("random", "human") else frame.get("condition", "no_plan")
    elapsed = frame.get("seconds")
    footer = f"{method} / {note}" + (f" / {elapsed:.2f}s" if elapsed is not None else "")
    draw.text((24,image.height-25), footer, font=font(10), fill=MUTED)
    return image


def decision_frame(state, *, result=None, **metadata):
    return {"state": state, "question": QUESTION, "choices": CHOICES,
            "status": "decision" if result else "thinking", **metadata, **(result or {})}


def gif_bytes(frames, layout="card"):
    if layout not in ("card", "board"):
        raise ValueError("GIF layout must be card or board")
    if not frames:
        raise ValueError("No frames to export")
    images = [(render_card(f) if layout == "card" else
               game_from_state(f["state"]).render(f.get("render_version", "topology_v2"))) for f in frames]
    size = (max(im.width for im in images), max(im.height for im in images))
    padded = []
    for im in images:
        canvas = Image.new("RGB", size, BG)
        canvas.paste(im, (0,0))
        padded.append(canvas)
    output = BytesIO()
    durations = [1200 if f.get("final") else 600 for f in frames]
    padded[0].save(output, format="GIF", save_all=True, append_images=padded[1:], duration=durations,
                   loop=0, disposal=2)
    return output.getvalue()
