"""Browser-only entry point. Imports only the published environment allowlist."""
import base64
import hashlib
import json
from io import BytesIO

_game = None
_case = None
_bench = None
_track = None


def dispatch(request):
    global _game, _case, _bench, _track
    op = request['type']
    if op == 'dispose':
        _game = _case = None
        clear_ink()
        return {'disposed': True}
    if op in ('init', 'reset'):
        clear_ink()
        _case = request.get('case', _case)
        _bench = request.get('bench', _bench)
        _track = request.get('track', _track) or 'geometry'
        if _bench == 'snake':
            from vdecision.benches.snake.rendering import game_from_state
            _game = game_from_state(_case['state'])
        elif _bench == 'drawing':
            from vdecision.benches.drawing.v2_environment import DrawingV2
            _game = DrawingV2(_case, _track)
        else:
            raise ValueError('Unsupported benchmark')
    elif op == 'step':
        _game.step(request['action'])
    elif op != 'evaluate':
        raise ValueError('Unknown message type')
    if _game is None:
        raise ValueError('Initialize a session first')
    if _bench == 'snake':
        img = _game.render()
        public = _game.state()
        metrics = dict(foods=_game.foods, steps=_game.steps, terminal=_game.terminal)
    else:
        from vdecision.benches.drawing.v2_rendering import render
        from vdecision.benches.drawing.v2_scoring import evaluate
        img = render(_game)
        public = _game.public_state()
        metrics = evaluate(_game) if op == 'evaluate' or _game.terminal else None
    stream = BytesIO()
    img.save(stream, format='PNG')
    return dict(state=public, image=base64.b64encode(stream.getvalue()).decode(),
                pixel_hash=hashlib.sha256(img.tobytes()).hexdigest(),
                terminal=_game.terminal, metrics=metrics,
                ink_hashes=[(o['ink'], o['erased']) for o in _game.objects] if _bench == 'drawing' else [])


def clear_ink():
    import sys
    ink = sys.modules.get('vdecision.benches.drawing.v2_ink')
    if ink:
        ink._ASSETS.clear()
        ink.get.cache_clear()
        # EMPTY is a content-addressed all-zero mask.
        import numpy as np
        ink.put(np.zeros((ink.SIZE, ink.SIZE), dtype=np.uint8))
